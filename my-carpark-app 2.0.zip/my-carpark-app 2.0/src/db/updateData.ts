//update password,using verification of name and email by user and data from database (reset password)

import { eq } from 'drizzle-orm';
import { db } from './index';  // Import the db connection from index.ts
import { usersTable } from './schema';  // Import schema for usersTable
import readline from 'readline';  // Import readline for interactive user input

/**
 * Get user data by name and email.
 *
 * @param name - The name of the user to check.
 * @param email - The email of the user to check.
 * @returns {Promise<any | null>} - The user object if found, null otherwise.
 */
async function getUserByNameAndEmail(name: string, email: string): Promise<any | null> {
  const result = await db
    .select()
    .from(usersTable);  // Fetch all users
  
  // Return the user if both name and email match
  const user = result.find(user => user.name === name && user.email === email);
  return user || null;  // If no matching user is found, return null
}

/**
 * Prompt the user for input.
 *
 * @param rl - The readline interface to prompt the user
 * @param question - The question to ask the user
 * @returns {Promise<string>} - The user’s input as a string
 */
function promptUser(rl: readline.Interface, question: string): Promise<string> {
  return new Promise<string>((resolve) => {
    rl.question(question, (answer) => {
      resolve(answer);
    });
  });
}

/**
 * Update user password by name and email.
 * Prompts user for their name, email, and new password.
 *
 * @param name - The name of the user to update
 * @param email - The email of the user to verify
 * @param data - The fields to update (e.g., password)
 */
async function updateUserData(name: string, email: string, data: Partial<{ password: string }>) {
  try {
    const user = await getUserByNameAndEmail(name, email);  // Check if user exists by name and email
    
    if (!user) {
      console.log(`User with name ${name} and email ${email} not found.`);
      return;
    }

    // Directly assign the password from the input (no hashing)
    if (data.password) {
      data.password = data.password;  // No hashing applied
    }

    // Proceed with the update after handling the password
    const result = await db
      .update(usersTable)
      .set(data)
      .where(eq(usersTable.id, user.id));  // Update user data by user id (which is unique)
    
    // Check if the update was successful
    const updatedUser = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, user.id));  // Query the user again to confirm the update
    
    if (updatedUser.length > 0) {
      console.log(`User with name ${name} and email ${email} updated successfully!`);
      console.log('Updated User:', updatedUser);
    } else {
      console.log(`No changes were made to user ${name}.`);
    }
  } catch (error) {
    console.error('Error updating user:', error);
  }
}

/**
 * Example function to prompt the user for their name, email, and new password.
 * This will update a user's password if valid name and email are provided.
 */
async function promptAndUpdateUser() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  try {
    // Prompt the user for input: name, email, and new password
    const name = await promptUser(rl, 'Please enter your username: ');
    const email = await promptUser(rl, 'Please enter your email: ');

    // Verify that the user with this name and email exists
    const user = await getUserByNameAndEmail(name, email);
    if (!user) {
      console.log(`No user found with the name ${name} and email ${email}.`);
      rl.close();
      return;
    }

    // Prompt the user for the new password
    const newPassword = await promptUser(rl, 'Please enter your new password: ');

    // Update the user data with the new password
    await updateUserData(name, email, { password: newPassword });

  } catch (error) {
    console.error('Error:', error);
  } finally {
    rl.close();  // Close the readline interface after the operation
  }
}

// Run the promptAndUpdateUser function
promptAndUpdateUser();
