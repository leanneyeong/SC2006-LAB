import readlineSync from 'readline-sync';  // For interactive user input
import { handleResetPassword } from '../controllers/resetpwController';  // Import the reset password controller

/**
 * Function to prompt user input and handle password reset
 */
async function promptAndResetPassword() {
  // Step 1: Prompt for username and password
  const name = readlineSync.question('Enter your username: ');
  const password = readlineSync.question('Enter your current password: ', { hideEchoBack: true });
  
  // Step 2: Prompt for the new password
  const newPassword = readlineSync.question('Enter your new password: ', { hideEchoBack: true });

  // Try to handle the reset process with the provided credentials and new password
  const resetSuccess = await handleResetPassword(name, password, newPassword, '');  // Empty email initially

  if (resetSuccess) {
    console.log('Password reset successfully!');
    return;
  }

  // If credentials are wrong, prompt for email
  const email = readlineSync.question('Password is incorrect. Enter your email address to verify: ');

  const resetByEmailSuccess = await handleResetPassword(name, '', newPassword, email);  // Verify with email if name+password fails
  
  if (resetByEmailSuccess) {
    console.log('Password reset successfully via email verification!');
  } else {
    console.log('Failed to reset password. Either email is incorrect or does not match the username.');
  }
}

// Run the password reset process
promptAndResetPassword();
