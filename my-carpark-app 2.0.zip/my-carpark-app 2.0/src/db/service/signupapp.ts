import { config } from 'dotenv';
import readlineSync from 'readline-sync';  // For interactive user input
import { handleSignup } from '../controllers/signupController';  // Import the signup controller

// Load environment variables
config({ path: '.env' });

// Function to prompt user input and perform signup
async function promptAndSignup() {
  // Prompt for username, password, and email
  const name = readlineSync.question('Enter your username: ');
  const password = readlineSync.question('Enter your password: ', { hideEchoBack: true });
  const email = readlineSync.question('Enter your email: ');

  // Call the signup controller to handle the signup logic
  await handleSignup(name, password, email);
}

// Run the signup process
promptAndSignup();
