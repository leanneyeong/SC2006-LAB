//login interaction

import { config } from 'dotenv';
import { drizzle } from 'drizzle-orm/libsql';
import readlineSync from 'readline-sync';  // For interactive user input
import { handleLogin } from '../db/loginController';  // Import the login controller

// Load environment variables
config({ path: '.env' });

// Initialize the database connection using drizzle-orm
export const db = drizzle({
  connection: {
    url: process.env.TURSO_CONNECTION_URL!,
    authToken: process.env.TURSO_AUTH_TOKEN!,
  },
});

// Function to prompt user input and perform login
async function promptAndLogin() {
  // Prompt for username and password
  const name = readlineSync.question('Enter your username: ');
  const password = readlineSync.question('Enter your password: ', { hideEchoBack: true });

  // Call the login controller to handle login logic
  await handleLogin(name, password);
}

// Run the login process
promptAndLogin();
