import { db } from './index';  // Import the db connection from index.ts
import { usersTable } from './schema';  // Import schema for usersTable
import { eq } from 'drizzle-orm';  // Import eq for query building
import readline from 'readline';  // Import readline for interactive user input

/**
 * Check if a user exists by name before attempting to delete.
 * 
 * @param name - The name of the user to check.
 * @returns {Promise<boolean>} - Whether the user exists.
 */
async function doesUserExist(name: string): Promise<boolean> {
  const result = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.name, name));  // Search by name
  
  console.log('User search result:', result);  // Log result to see what users are found
  return result.length > 0;  // If result has length, user exists
}

/**
 * Delete user data by name.
 *
 * @param name - The name of the user to delete
 */
async function deleteUserData(name: string) {
  try {
    const userExists = await doesUserExist(name);  // Check if user exists by name
    
    if (!userExists) {
      console.log(`User with name ${name} not found.`);
      return;
    }

    // If the user exists, proceed with the delete operation
    await db
      .delete(usersTable)
      .where(eq(usersTable.name, name));  // Delete user by name
    
    // Verify if the user was actually deleted by querying again
    const deletedUser = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.name, name));  // Query the user again to confirm the deletion
    
    // Check if the user still exists
    if (deletedUser.length === 0) {
      console.log(`User with name ${name} deleted successfully!`);
    } else {
      console.log(`Failed to delete user with name ${name}.`);
    }
  } catch (error) {
    console.error('Error deleting user:', error);
  }
}

/**
 * Prompt the admin for input.
 *
 * @param rl - The readline interface to prompt the user
 * @param question - The question to ask the admin
 * @returns {Promise<string>} - The admin’s input as a string
 */
function promptAdmin(rl: readline.Interface, question: string): Promise<string> {
  return new Promise<string>((resolve) => {
    rl.question(question, (answer) => {
      resolve(answer);
    });
  });
}

/**
 * Example function to prompt the admin for a user's name and delete that user.
 * This will delete a user with the given name if found.
 */
async function promptAndDeleteUser() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  try {
    // Prompt the admin for input: name of the user to delete
    const name = await promptAdmin(rl, 'Please enter the name of the user to delete: ');

    // Delete the user with the given name
    await deleteUserData(name);

  } catch (error) {
    console.error('Error:', error);
  } finally {
    rl.close();  // Close the readline interface after the operation
  }
}

// Run the promptAndDeleteUser function
promptAndDeleteUser();
