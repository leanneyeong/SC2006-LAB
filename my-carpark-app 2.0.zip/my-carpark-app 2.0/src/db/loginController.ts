import { loginUser } from './queries/login';  // Import the login service

/**
 * Controller function to handle the login process.
 * @param name - The username provided by the user.
 * @param password - The password provided by the user.
 */
export async function handleLogin(name: string, password: string) {
  const isAuthenticated = await loginUser(name, password);  // Call the login service

  if (isAuthenticated) {
    console.log('You have logged in successfully!');
  } else {
    console.log('Login failed. Please check your credentials.');
  }
}
