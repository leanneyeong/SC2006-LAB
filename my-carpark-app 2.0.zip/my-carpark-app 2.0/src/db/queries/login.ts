import { db } from '../index';  // Import your database connection
import { usersTable } from '../schema';  // Assuming the schema is defined here
import { eq } from 'drizzle-orm';  // Import eq for condition matching

/**
 * Function to log in a user and compare the password.
 * @param name - The username provided by the user.
 * @param password - The password provided by the user.
 */
export async function loginUser(name: string, password: string) {
  try {
    // Query the database for the user by username using the eq condition
    const result = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.name, name))  // Use eq to match name with the column name
      .limit(1);  // Limit to only one result (optional)

    if (result.length === 0) {
      console.log('User not found');
      return false;
    }

    const storedUser = result[0];  // Get the user data (first row)
    console.log('User found in DB:', storedUser);

    // Compare the entered password with the stored plaintext password
    console.log('Comparing passwords...');
    
    // Directly compare the plaintext password
    if (password === storedUser.password) {
      console.log('Login successful');
      return true;
    } else {
      console.log('Invalid credentials');
      return false;
    }
  } catch (error) {
    console.error('Error during login:', error);
    return false;
  }
}
