import { db } from '../index';  // Import your database connection
import { usersTable } from '../schema';  // Assuming the schema is defined here
import { eq } from 'drizzle-orm';  // Import eq for condition matching

// Function to update the user's password in the database
export async function updateUserPassword(userId: number, newPassword: string) {
  try {
    // Update the password in the database
    await db
      .update(usersTable)
      .set({ password: newPassword })  // Set the new password
      .where(eq(usersTable.id, userId));  // Match by user ID
    console.log('Password updated successfully!');
  } catch (error) {
    console.error('Error updating user password:', error);
  }
}

// Function to get a user by name for verification
export async function getUserByName(name: string) {
  try {
    const result = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.name, name));  // Match the name

    if (result.length > 0) {
      return result[0];  // Return the first matched user
    } else {
      return null;  // No user found with the provided name
    }
  } catch (error) {
    console.error('Error finding user by name:', error);
    return null;
  }
}

// Function to get a user by email for verification
export async function getUserByEmail(email: string) {
  try {
    const result = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.email, email));  // Match the email

    if (result.length > 0) {
      return result[0];  // Return the first matched user
    } else {
      return null;  // No user found with the provided email
    }
  } catch (error) {
    console.error('Error finding user by email:', error);
    return null;
  }
}

// Function to verify the username and password manually
export async function verifyUserCredentials(name: string, password: string) {
  const user = await getUserByName(name);
  if (user && password === user.password) {
    return user;  // Return user object if credentials are valid
  }
  return null;  // Return null if credentials don't match
}
