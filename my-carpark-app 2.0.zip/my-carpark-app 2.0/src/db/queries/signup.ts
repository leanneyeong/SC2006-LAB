import { db } from '../index';  // Your database connection
import { usersTable } from '../schema';  // The schema where you define the users table

/**
 * Function to create a new user in the database.
 * @param name - The username.
 * @param password - The password of the user.
 * @param email - The email of the user.
 */
export async function createUser({ name, password, email }: { name: string; password: string; email: string }) {
  try {
    // Insert user data into the database
    const result = await db
      .insert(usersTable)
      .values({ name, password, email });

    console.log(`User ${name} created successfully!`);
  } catch (error) {
    console.error('Error inserting user:', error);
  }
}
