import { verifyUserCredentials, getUserByEmail, updateUserPassword } from '../queries/resetpw';  // Import query functions

/**
 * Controller function to handle the password reset process.
 * @param name - The username provided by the user.
 * @param password - The current password provided by the user.
 * @param newPassword - The new password provided by the user.
 * @param email - The email provided by the user (if password is incorrect).
 * @returns A boolean indicating if the password was successfully reset.
 */
export async function handleResetPassword(name: string, password: string, newPassword: string, email: string) {
  // Step 1: Verify the username and password manually
  const user = await verifyUserCredentials(name, password);  // Validate the current credentials

  if (user) {
    // Step 2: If the credentials are correct, update the password
    console.log('Credentials verified. Proceeding to update the password...');
    await updateUserPassword(user.id, newPassword);  // Update the password for the verified user
    return true;  // Indicate successful password reset
  } else {
    // Step 3: If the credentials are incorrect, inform the user and ask for the email
    console.log('Password incorrect. Please enter your email for verification.');

    // Verify the email
    const userByEmail = await getUserByEmail(email);  // Try to match by email
    if (userByEmail && userByEmail.name === name) {
      console.log('Email verified. Proceeding to update the password...');
      await updateUserPassword(userByEmail.id, newPassword);  // Update the password for the user found by email
      return true;  // Indicate successful password reset via email verification
    } else {
      console.log('Email not found or does not match the username. Password reset failed.');
      return false;  // Indicate failure to reset password due to email mismatch
    }
  }
}
