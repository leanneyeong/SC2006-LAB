import { createUser } from '../queries/signup';  // Import the function to create a new user

/**
 * Controller function to handle the signup process.
 * @param name - The username provided by the user.
 * @param password - The password provided by the user.
 * @param email - The email provided by the user.
 */
export async function handleSignup(name: string, password: string, email: string) {
  try {
    // Call the createUser function to insert the user into the database
    await createUser({ name, password, email });

    console.log(`User ${name} has been signed up successfully!`);
  } catch (error) {
    console.error('Signup failed:', error);
  }
}
