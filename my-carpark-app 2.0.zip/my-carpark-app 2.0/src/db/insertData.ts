//users give username, password and email, put into database (sign up)

import { createUser } from './queries/insert';  // Import the function from insert.ts
import readline from 'readline';  // Import readline for interactive user input


/**
 * Prompt the user for input.
 *
 * @param rl - The readline interface to prompt the user
 * @param question - The question to ask the user
 * @returns {Promise<string>} - The user’s input as a string
 */
function promptUser(rl: readline.Interface, question: string): Promise<string> {
  return new Promise<string>((resolve) => {
    rl.question(question, (answer) => {
      resolve(answer);
    });
  });
}


/**
 * Insert user data into the database.
 * Prompts user for input (name, password, email).
 */
async function insertUserData() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });


  try {
    // Prompt the user for input: name, password, and email
    const name = await promptUser(rl, 'Please enter your username: ');
    const password = await promptUser(rl, 'Please enter your password: ');
    const email = await promptUser(rl, 'Please enter your email: ');

    // Insert the user into the database with the plain password (no hashing)
    await createUser({
      name: name,  // Name of the user
      password: password,  // Plain password of the user
      email: email,  // Email of the user
    });

    console.log(`User ${name} added successfully!`);
  } catch (error) {
    console.error('Error inserting user:', error);
  } finally {
    rl.close();  // Close the readline interface
  }
}

// Run the function to insert a user
insertUserData();
