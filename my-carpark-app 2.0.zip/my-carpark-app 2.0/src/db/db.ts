import { Client } from 'pg';
import dotenv from 'dotenv';  // Import dotenv to load environment variables from .env file

dotenv.config();  // Load environment variables from .env file

// Initialize the client using the environment variables
export const client = new Client({
  connectionString: process.env.TURSO_CONNECTION_URL,  // Use the Turso connection URL from the .env file
  ssl: { rejectUnauthorized: false }  // Ensure SSL connection is used (common for cloud databases like Turso)
});

// Connect to the database
client.connect()
  .then(() => console.log("Successfully connected to Turso database"))
  .catch((err) => console.error('Connection error', err.stack));
